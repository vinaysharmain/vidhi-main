const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
    content: {
        type: String,
        required: true,
        maxLength: 1000
    },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    username: {
        type: String,
        required: true
    },
    team: {
        type: String,
        enum: ['team1', 'team2'],
        required: true
    },
    type: {
        type: String,
        enum: ['text', 'voice'],
        default: 'text'
    },
    mediaUrl: String,
    timestamp: {
        type: Date,
        default: Date.now
    }
});

const pollSchema = new mongoose.Schema({
    question: {
        type: String,
        required: true
    },
    votes: {
        valid: { type: Number, default: 0 },
        invalid: { type: Number, default: 0 }
    },
    voters: [{
        userId: mongoose.Schema.Types.ObjectId,
        vote: String
    }],
    createdAt: {
        type: Date,
        default: Date.now
    }
});

const debateSchema = new mongoose.Schema({
    topic: {
        type: String,
        required: true,
        index: true
    },
    status: {
        type: String,
        enum: ['active', 'completed', 'cancelled'],
        default: 'active'
    },
    participants: [{
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        },
        username: String,
        team: {
            type: String,
            enum: ['team1', 'team2']
        },
        joinedAt: {
            type: Date,
            default: Date.now
        }
    }],
    messages: [messageSchema],
    polls: [pollSchema],
    points: {
        team1: { type: Number, default: 0 },
        team2: { type: Number, default: 0 }
    },
    startedAt: {
        type: Date,
        default: Date.now
    },
    endedAt: Date,
    maxParticipants: {
        type: Number,
        default: 10
    }
}, {
    timestamps: true
});

// Indexes
debateSchema.index({ status: 1, startedAt: -1 });
debateSchema.index({ 'participants.userId': 1 });

// Methods
debateSchema.methods.addParticipant = function(userId, username, team) {
    if (this.participants.length >= this.maxParticipants) {
        throw new Error('Debate has reached maximum participants limit');
    }
    
    if (this.participants.some(p => p.userId.equals(userId))) {
        throw new Error('User is already a participant');
    }
    
    this.participants.push({ userId, username, team });
    return this.save();
};

debateSchema.methods.removeParticipant = function(userId) {
    this.participants = this.participants.filter(p => !p.userId.equals(userId));
    return this.save();
};

debateSchema.methods.addMessage = function(message) {
    if (this.status !== 'active') {
        throw new Error('Cannot add message to inactive debate');
    }
    this.messages.push(message);
    return this.save();
};

const Debate = mongoose.model('Debate', debateSchema);

module.exports = Debate; 