const rateLimit = require('express-rate-limit');
const config = require('../config');

const apiLimiter = rateLimit({
    windowMs: config.rateLimit.windowMs,
    max: config.rateLimit.max,
    message: {
        error: 'Too many requests from this IP, please try again later.'
    },
    standardHeaders: true,
    legacyHeaders: false
});

const socketRateLimiter = new Map();

const socketLimiter = (socket, next) => {
    const ip = socket.handshake.address;
    const now = Date.now();
    
    if (!socketRateLimiter.has(ip)) {
        socketRateLimiter.set(ip, {
            count: 1,
            firstRequest: now
        });
        return next();
    }

    const limiter = socketRateLimiter.get(ip);
    const timeElapsed = now - limiter.firstRequest;

    if (timeElapsed > config.rateLimit.windowMs) {
        limiter.count = 1;
        limiter.firstRequest = now;
        return next();
    }

    if (limiter.count >= config.rateLimit.max) {
        return next(new Error('Rate limit exceeded'));
    }

    limiter.count++;
    next();
};

// Cleanup old rate limit entries periodically
setInterval(() => {
    const now = Date.now();
    for (const [ip, data] of socketRateLimiter.entries()) {
        if (now - data.firstRequest > config.rateLimit.windowMs) {
            socketRateLimiter.delete(ip);
        }
    }
}, config.rateLimit.windowMs);

module.exports = {
    apiLimiter,
    socketLimiter
}; 