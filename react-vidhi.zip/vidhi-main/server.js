require('dotenv').config();
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const mongoose = require('mongoose');
const cors = require('cors');
const { CohereClient } = require('cohere-ai');
const path = require('path');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const winston = require('winston');
const jwt = require('jsonwebtoken');

const config = require('./config');
const { auth } = require('./middleware/auth');
const { apiLimiter, socketLimiter } = require('./middleware/rateLimiter');
const Debate = require('./models/Debate');
const User = require('./models/User');

// Configure Winston logger
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [
        new winston.transports.File({ filename: 'error.log', level: 'error' }),
        new winston.transports.File({ filename: 'combined.log' })
    ]
});

if (process.env.NODE_ENV !== 'production') {
    logger.add(new winston.transports.Console({
        format: winston.format.simple()
    }));
}

// Initialize Express app
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: config.clientUrl,
        methods: ["GET", "POST"]
    }
});

// Connect to MongoDB
mongoose.connect(config.mongodbUri)
    .then(() => logger.info('Connected to MongoDB'))
    .catch(err => {
        logger.error('MongoDB connection error:', err);
        process.exit(1);
    });

// Initialize Cohere client
const cohere = new CohereClient({
    token: config.cohereApiKey
});

// Middleware
app.use(helmet());
app.use(compression());
app.use(morgan('combined'));
app.use(cors({
    origin: config.clientUrl,
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', apiLimiter);

// Socket.IO middleware
io.use(socketLimiter);
io.use(async (socket, next) => {
    try {
        const token = socket.handshake.auth.token;
        if (!token) {
            throw new Error('Authentication required');
        }

        const decoded = jwt.verify(token, config.jwtSecret);
        const user = await User.findById(decoded._id);
        
        if (!user) {
            throw new Error('User not found');
        }

        socket.user = user;
        next();
    } catch (error) {
        next(new Error('Authentication failed'));
    }
});

// Socket.IO connection handling
io.on('connection', async (socket) => {
    logger.info(`User connected: ${socket.user.username}`);

    socket.on('joinDebate', async (data) => {
        try {
            const { topic, team } = data;
            let debate = await Debate.findOne({ topic, status: 'active' });

            if (!debate) {
                debate = new Debate({
                    topic,
                    participants: [],
                    messages: [],
                    polls: []
                });
            }

            await debate.addParticipant(socket.user._id, socket.user.username, team);
            
            socket.join(topic);
            socket.emit('debateJoined', { topic, team });
            io.to(topic).emit('userJoined', { 
                username: socket.user.username,
                team 
            });

            // Update user's debates participated
            await User.findByIdAndUpdate(socket.user._id, {
                $addToSet: {
                    debatesParticipated: {
                        debateId: debate._id,
                        role: team,
                        joinedAt: new Date()
                    }
                }
            });

        } catch (error) {
            logger.error('Join debate error:', error);
            socket.emit('error', { message: error.message });
        }
    });

    socket.on('sendMessage', async (message) => {
        try {
            const debate = await Debate.findOne({ 
                topic: message.topic,
                status: 'active'
            });

            if (!debate) {
                throw new Error('Debate not found or inactive');
            }

            const newMessage = {
                content: message.content,
                userId: socket.user._id,
                username: socket.user.username,
                team: message.team,
                type: 'text'
            };

            await debate.addMessage(newMessage);
            
            io.to(message.topic).emit('receiveMessage', newMessage);
        } catch (error) {
            logger.error('Send message error:', error);
            socket.emit('error', { message: error.message });
        }
    });

    socket.on('sendVoiceMessage', async (message) => {
        try {
            const debate = await Debate.findOne({ 
                topic: message.topic,
                status: 'active'
            });

            if (!debate) {
                throw new Error('Debate not found or inactive');
            }

            const newMessage = {
                content: message.content,
                userId: socket.user._id,
                username: socket.user.username,
                team: message.team,
                type: 'voice',
                mediaUrl: message.mediaUrl
            };

            await debate.addMessage(newMessage);
            
            io.to(message.topic).emit('receiveVoiceMessage', newMessage);
        } catch (error) {
            logger.error('Send voice message error:', error);
            socket.emit('error', { message: error.message });
        }
    });

    socket.on('votePoll', async (data) => {
        try {
            const debate = await Debate.findOne({ 
                topic: data.topic,
                status: 'active'
            });

            if (!debate) {
                throw new Error('Debate not found or inactive');
            }

            const poll = debate.polls.id(data.pollId);
            if (!poll) {
                throw new Error('Poll not found');
            }

            // Check if user has already voted
            if (poll.voters.some(v => v.userId.equals(socket.user._id))) {
                throw new Error('You have already voted in this poll');
            }

            // Add vote
            poll.votes[data.vote]++;
            poll.voters.push({
                userId: socket.user._id,
                vote: data.vote
            });

            await debate.save();

            io.to(data.topic).emit('pollUpdate', {
                pollId: data.pollId,
                votes: poll.votes,
                totalVotes: poll.voters.length
            });
        } catch (error) {
            logger.error('Vote poll error:', error);
            socket.emit('error', { message: error.message });
        }
    });

    socket.on('checkFact', async (data) => {
        try {
            const response = await cohere.generate({
                prompt: `Fact check this statement: ${data.text}`,
                max_tokens: 300,
                temperature: 0.7,
                k: 0,
                stop_sequences: [],
                return_likelihoods: 'NONE'
            });

            const result = {
                original: data.text,
                result: response.body.generations[0].text,
                timestamp: new Date().toISOString()
            };

            socket.emit('factCheckResult', result);
        } catch (error) {
            logger.error('Fact check error:', error);
            socket.emit('error', { message: 'Error checking fact' });
        }
    });

    socket.on('disconnect', async () => {
        try {
            // Remove user from all active debates
            const activeDebates = await Debate.find({ 
                'participants.userId': socket.user._id,
                status: 'active'
            });

            for (const debate of activeDebates) {
                await debate.removeParticipant(socket.user._id);
                io.to(debate.topic).emit('userLeft', { 
                    username: socket.user.username 
                });
            }

            logger.info(`User disconnected: ${socket.user.username}`);
        } catch (error) {
            logger.error('Disconnect error:', error);
        }
    });
});

// API Routes
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'ok',
        timestamp: new Date().toISOString()
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    logger.error(err.stack);
    res.status(500).json({ 
        error: 'Something went wrong!',
        message: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
});

// Start server
const PORT = config.port;
server.listen(PORT, () => {
    logger.info(`Server running on port ${PORT}`);
}); 