const Joi = require('joi');
const dotenv = require('dotenv');

dotenv.config();

const envSchema = Joi.object({
    NODE_ENV: Joi.string().valid('development', 'production', 'test').default('development'),
    PORT: Joi.number().default(5000),
    CLIENT_URL: Joi.string().uri().required(),
    COHERE_API_KEY: Joi.string().required(),
    MONGODB_URI: Joi.string().required(),
    JWT_SECRET: Joi.string().required(),
    RATE_LIMIT_WINDOW: Joi.number().default(15 * 60 * 1000), // 15 minutes
    RATE_LIMIT_MAX: Joi.number().default(100),
    MAX_PARTICIPANTS_PER_DEBATE: Joi.number().default(10),
    MAX_MESSAGE_LENGTH: Joi.number().default(1000),
    DEBATE_TIMEOUT: Joi.number().default(3600000), // 1 hour in milliseconds
}).unknown();

const { error, value: envVars } = envSchema.validate(process.env);

if (error) {
    throw new Error(`Config validation error: ${error.message}`);
}

const config = {
    env: envVars.NODE_ENV,
    port: envVars.PORT,
    clientUrl: envVars.CLIENT_URL,
    cohereApiKey: envVars.COHERE_API_KEY,
    mongodbUri: envVars.MONGODB_URI,
    jwtSecret: envVars.JWT_SECRET,
    rateLimit: {
        windowMs: envVars.RATE_LIMIT_WINDOW,
        max: envVars.RATE_LIMIT_MAX
    },
    debate: {
        maxParticipants: envVars.MAX_PARTICIPANTS_PER_DEBATE,
        maxMessageLength: envVars.MAX_MESSAGE_LENGTH,
        timeout: envVars.DEBATE_TIMEOUT
    }
};

module.exports = config; 